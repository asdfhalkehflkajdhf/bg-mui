<html>
	<head>
		<title>男生女生</title>
		<meta charset="utf-8" />

	</head>
	<body>
		<center><h2>Welcome to Wnmp 3.1.0!</h2></center>
		<center><h2>by <a href="https://www.x64architecture.com/">Kurt Cancemi</a></h2></center>
		<center><h2><a href="https://www.getwnmp.org/">Wnmp Website</a></h2></center>
		<center>Click <a href="http://localhost/phpmyadmin/">here</a> to go to phpMyAdmin</center>
		<br />
		<?php 
		phpinfo();
		?>
	</body>
</html>