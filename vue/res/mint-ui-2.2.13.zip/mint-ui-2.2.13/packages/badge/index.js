export { default } from './src/badge.vue';
