export { default } from './src/switch.vue';
