export { default } from './src/tab-container-item.vue';
